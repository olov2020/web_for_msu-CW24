from .course_service import CourseService
from .image_service import ImageService
from .mark_service import MarkService
from .news_service import NewsService
from .pupil_service import PupilService
from .teacher_service import TeacherService
from .user_service import UserService
